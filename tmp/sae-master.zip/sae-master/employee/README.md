# Employee Application Functionality

The Employee Application will house the Employee model and will act as the interface for adding/editing/removing employee information



TODO
- Display a directory of all employees

- Allow to filter by job title

- Map Employee fname+lname to User authentication module

- Employee profile 