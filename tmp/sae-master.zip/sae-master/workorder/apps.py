from django.apps import AppConfig


class WorkorderConfig(AppConfig):
    name = 'workorder'
