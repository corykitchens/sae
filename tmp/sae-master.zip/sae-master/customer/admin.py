from django.contrib import admin
from .models import Customer, Customer_Address
# Register your models here.
admin.site.register(Customer)
admin.site.register(Customer_Address)