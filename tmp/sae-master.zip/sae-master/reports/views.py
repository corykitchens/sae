from django.shortcuts import render

# Create your views here.
def day_report(request):
	#Given a date

	#Take all employees that are currently working

	#Multiply all salaries, store in total_emp_salaries

	#Take Number of work orders opened on that date


	