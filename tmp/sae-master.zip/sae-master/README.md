# Automotive Service &amp; Repair Application

This project is in conjecture with the CS342 database project. The aim of this project is to create an application that will allow automotive service staff to create,edit,update, delete work orders. Added functionality will include a messaging/news and announcements system that will allow employees to communicate with each other across interchanging staff schedules.

### Version
0.0.1

### Tech
Django (version 1.8)
Python (version 2.7+)
Oracle Server (version 11g)
